rm(list = ls())
options(repos = c(CRAN = "http://cran.rstudio.com"))

global_para <- list(rep=10, lambda =2^seq(-10,2,by=0.25), lambdavec = 2^seq(-20,1,by=0.5),
                    rho_hub = 0.2, rho_band = 0.3, rho_rand = 0.2, t_df=5)

n_cluster <- 20

## library ----------------------------------------------------------
name_pkg <- c(
  # Analysis
  "expm",
  "glasso",
  "glmnet",
  "mvtnorm",
  "tidyverse",
  # Parallelization
  "foreach",
  "doParallel",
  # Visualization
  "here",
  "ggplot2",
  "grid",
  "abind",
  "gridExtra"
)
name_pkg <- unique(name_pkg)
invisible(lapply(name_pkg, library, character.only = T)) # load multiple packages

## source ----------------------------------------------------------
setwd(here())
source(here("matrixNS_functions.R"))

## Simulation settings -----------------------------------------------------
paragrid <- expand.grid(
  n = c(20),
  p = c(20),
  q = c(20),
  type_graph = c("hub","band","random"),
  stringsAsFactors = FALSE
)
paragrid$rho <- NA
paragrid$rho[paragrid$type_graph == "hub"] <- global_para$rho_hub
paragrid$rho[paragrid$type_graph == "band"] <- global_para$rho_band
paragrid$rho[paragrid$type_graph == "random"] <- global_para$rho_rand
paragrid$rho[paragrid$type_graph == "identity"] <- 1

print(
  knitr::kable(paragrid, format = "simple", row.names = T)
)
paragrid_long <- paragrid[rep(1:nrow(paragrid), each = global_para$rep),,drop = F]


## Assign clusters for parallel computing ----------------------------------------------------------
cl <- makeCluster(n_cluster,
                  outfile = "Result_verbose.txt")
registerDoParallel(cl)

## Initialize --------------
n <- 0
p <- 0
q <- 0
U <- 0
V <- 0
cov.type <- 0
rep_tmp <- list()
result_NS <- list()
result_all = list()
result_tmp <- matrix(0, nrow=length(global_para$lambda), ncol=3)
auc_row_tmp <- c()
auc_col_tmp <- c()
est_Uinv<-0
est_Vinv<-0

## Timing (start) ----------------------------------------------------------
start_time <- Sys.time()
for(i in 1:nrow(paragrid)){
  ## data generation
  n = paragrid$n[i]
  p = paragrid$p[i]
  q = paragrid$q[i]
  cov.type = paragrid$type_graph[i]
  Uinv <- Covmat[["band"]](p,global_para$rho_band)
  Vinv <- Covmat[[cov.type]](q,paragrid$rho[i])
  U <- solve(Uinv)
  V <- solve(Vinv)
  cat("n=",n,", p=",p,", q=",q,", type=",cov.type,"\n",sep="")
  auc_row_tmp <- c()
  auc_col_tmp <- c()
  Sigmainv <- kronecker(Vinv,Uinv)
  
  set.seed(1234)
  rep_tmp[[i]] <- foreach(r = 1:global_para$rep, .packages = name_pkg, .combine = function(x, y){
    list(
      result_tmp = mysum(x$result_tmp, y$result_tmp),
      auc.vec = c(x$auc.vec, y$auc.vec)
    )
  }) %dopar% { 
    Xdata <- matnormgen(n,U,V)
    if(T){
      mat_array <- abind(Xdata, along = 3)
      mat_mean <- apply(mat_array, 1:2, mean)
      mat_sd <- apply(mat_array, 1:2, sd)
      Xdata_std <- lapply(Xdata, function(df) (df - mat_mean) / mat_sd)
    }
    
    ## data analysis
    for(j in 1:length(global_para$lambda)){
      lam <- global_para$lambda[j]
      est_Uinv <- matrixrowNS(Xdata, lam)$and
      est_Vinv <- matrixcolNS(Xdata, lam)$and
      est_Sigmainv <- kronecker(est_Vinv, est_Uinv)
      eval_NS_vec <- evalNS(est_Sigmainv,Sigmainv)
      result_tmp[j,1] <- lam
      result_tmp[j,2] <- eval_NS_vec$false.positive.rate
      result_tmp[j,3] <- 1 - eval_NS_vec$false.negative.rate
    }
    auc_vec_tmp = myAUC2(result_tmp[,2], result_tmp[,3])
    return(list(result_tmp = result_tmp, auc.vec = auc_vec_tmp))
  }
  result_NS[[i]] <- data.frame(rep_tmp[[i]]$result_tmp/global_para$rep, n, p, q, cov.type,"NS",
                               mean(rep_tmp[[i]]$auc.vec),sd(rep_tmp[[i]]$auc.vec))
  colnames(result_NS[[i]]) <- c('lambda', 'vec_FP_rate', 'vec_TP_rate',
                                'n','p','q','cov.type','method',"vec_AUC", "vec_AUC_sd")
}
end_time = Sys.time()
elp_time = end_time-start_time ; elp_time
names(result_NS) <- apply(paragrid, 1, test_naming)


## method: GEMINI
n <- 0
p <- 0
q <- 0
U <- 0
V <- 0
cov.type <- 0
rep_tmp <- list()
result_GEM <- list()
result_all = list()
result_tmp <- matrix(0, nrow=length(global_para$lambda), ncol=3)
auc_row_tmp <- c()
auc_col_tmp <- c()
est_Uinv<-0
est_Vinv<-0

start_time_GEM <- Sys.time()
for(i in 1:nrow(paragrid)){
  ## data generation
  n = paragrid$n[i]
  p = paragrid$p[i]
  q = paragrid$q[i]
  cov.type = paragrid$type_graph[i]
  Uinv <- Covmat[["band"]](p,global_para$rho_band)
  Vinv <- Covmat[[cov.type]](q,paragrid$rho[i])
  U <- solve(Uinv)
  V <- solve(Vinv)
  cat("n=",n,", p=",p,", q=",q,", type=",cov.type,"\n",sep="")
  auc_row_tmp <- c()
  auc_col_tmp <- c()
  Sigmainv <- kronecker(Vinv,Uinv)
  
  set.seed(1234)
  rep_tmp[[i]] <- foreach(r = 1:global_para$rep, .packages = name_pkg, .combine = function(x, y){
    list(
      result_tmp = mysum(x$result_tmp, y$result_tmp),
      auc.vec = c(x$auc.vec, y$auc.vec)
    )
  }) %dopar% { 
    Xdata <- matnormgen(n,U,V)
    ## data analysis
    for(j in 1:length(global_para$lambda)){
      lam <- global_para$lambda[j]
      est_Uinv <- GeminirowNS(Xdata, lam)
      est_Vinv <- GeminicolNS(Xdata, lam)
      est_Sigmainv <- kronecker(est_Vinv, est_Uinv)
      eval_GEM_vec <- evalNS(est_Sigmainv,Sigmainv)
      result_tmp[j,1] <- lam
      result_tmp[j,2] <- eval_GEM_vec$false.positive.rate
      result_tmp[j,3] <- 1 - eval_GEM_vec$false.negative.rate
    }
    auc_vec_tmp = myAUC2(result_tmp[,2], result_tmp[,3])
    return(list(result_tmp = result_tmp, auc.vec = auc_vec_tmp))
  }
  result_GEM[[i]] <- data.frame(rep_tmp[[i]]$result_tmp/global_para$rep, n, p, q, cov.type,"GEMINI",
                                mean(rep_tmp[[i]]$auc.vec),sd(rep_tmp[[i]]$auc.vec))
  colnames(result_GEM[[i]]) <- c('lambda', 'vec_FP_rate', 'vec_TP_rate',
                                'n','p','q','cov.type','method',"vec_AUC", "vec_AUC_sd")
}
end_time_GEM = Sys.time()
elp_time_GEM = end_time_GEM-start_time_GEM ; elp_time_GEM
names(result_GEM) <- apply(paragrid, 1, test_naming)

## method: Likelihood flip-flop
n <- 0
p <- 0
q <- 0
U <- 0
V <- 0
cov.type <- 0
rep_tmp <- list()
result_like <- list()
result_all = list()
result_tmp <- matrix(0, nrow=length(global_para$lambda), ncol=3)
auc_row_tmp <- c()
auc_col_tmp <- c()
est_Uinv<-0
est_Vinv<-0

start_time_like <- Sys.time()
for(i in 1:nrow(paragrid)){
  ## data generation
  n = paragrid$n[i]
  p = paragrid$p[i]
  q = paragrid$q[i]
  cov.type = paragrid$type_graph[i]
  Uinv <- Covmat[["band"]](p,global_para$rho_band)
  Vinv <- Covmat[[cov.type]](q,paragrid$rho[i])
  U <- solve(Uinv)
  V <- solve(Vinv)
  cat("n=",n,", p=",p,", q=",q,", type=",cov.type,"\n",sep="")
  auc_row_tmp <- c()
  auc_col_tmp <- c()
  Sigmainv <- kronecker(Vinv,Uinv)
  
  set.seed(1234)
  rep_tmp[[i]] <- foreach(r = 1:global_para$rep, .packages = name_pkg, .combine = function(x, y){
    list(
      result_tmp = mysum(x$result_tmp, y$result_tmp),
      auc.vec = c(x$auc.vec, y$auc.vec)
    )
  }) %dopar% { 
    Xdata <- matnormgen(n,U,V)
    
    for(j in 1:length(global_para$lambda)){
      lam <- global_para$lambda[j]
      est_Uinv <- LikeNS(Xdata,lam,lam)$row
      est_Vinv <- LikeNS(Xdata,lam,lam)$col
      est_Sigmainv <- kronecker(est_Vinv, est_Uinv)
      eval_like_vec <- evalNS(est_Sigmainv,Sigmainv)
      result_tmp[j,1] <- lam
      result_tmp[j,2] <- eval_like_vec$false.positive.rate
      result_tmp[j,3] <- 1 - eval_like_vec$false.negative.rate
    }
    auc_vec_tmp = myAUC2(result_tmp[,2], result_tmp[,3])
    return(list(result_tmp = result_tmp, auc.vec = auc_vec_tmp))
  }
  result_like[[i]] <- data.frame(rep_tmp[[i]]$result_tmp/global_para$rep, n, p, q, cov.type,"Likelihood",
                                mean(rep_tmp[[i]]$auc.vec),sd(rep_tmp[[i]]$auc.vec))
  colnames(result_like[[i]]) <- c('lambda', 'vec_FP_rate', 'vec_TP_rate',
                                 'n','p','q','cov.type','method',"vec_AUC", "vec_AUC_sd")
}

end_time_like = Sys.time()
elp_time_like = end_time_like - start_time_like ; elp_time_like
names(result_like) <- apply(paragrid, 1, test_naming)

## method: vectorized NS
n <- 0
p <- 0
q <- 0
U <- 0
V <- 0
cov.type <- 0
rep_tmp <- list()
result_vecNS <- list()
result_all = list()
result_tmp <- matrix(0, nrow=length(global_para$lambdavec), ncol=3)
auc_row_tmp <- c()
auc_col_tmp <- c()

start_time_vecNS <- Sys.time()
for(i in 1:nrow(paragrid)){
  ## data generation
  n = paragrid$n[i]
  p = paragrid$p[i]
  q = paragrid$q[i]
  cov.type = paragrid$type_graph[i]
  Uinv <- Covmat[["band"]](p,global_para$rho_band)
  Vinv <- Covmat[[cov.type]](q,paragrid$rho[i])
  U <- solve(Uinv)
  V <- solve(Vinv)
  cat("n=",n,", p=",p,", q=",q,", type=",cov.type,"\n",sep="")
  auc_row_tmp <- c()
  auc_col_tmp <- c()
  Sigmainv <- kronecker(Vinv,Uinv)
  
  set.seed(1234)
  rep_tmp[[i]] <- foreach(r = 1:global_para$rep, .packages = name_pkg, .combine = function(x, y){
    list(
      result_tmp = mysum(x$result_tmp, y$result_tmp),
      auc.vec = c(x$auc.vec, y$auc.vec)
    )
  }) %dopar% { 
    Xdata <- matnormgen(n,U,V)
    if(T){
      mat_array <- abind(Xdata, along = 3)
      mat_mean <- apply(mat_array, 1:2, mean)
      mat_sd <- apply(mat_array, 1:2, sd)
      Xdata_std <- lapply(Xdata, function(df) (df - mat_mean) / mat_sd)
    }
    
    ## data analysis
    for(j in 1:length(global_para$lambdavec)){
      lam <- global_para$lambdavec[j]
      est_vecNS_and<-vecNSsel(Xdata,lam)$and
      eval_vecNS_and <- evalNS(est_vecNS_and,Sigmainv)
      result_tmp[j,1] <- lam
      result_tmp[j,2] <- eval_vecNS_and$false.positive.rate
      result_tmp[j,3] <- 1 - eval_vecNS_and$false.negative.rate
    }
    auc_vec_tmp = myAUC2(result_tmp[,2], result_tmp[,3])
    return(list(result_tmp = result_tmp, auc.vec = auc_vec_tmp))
  }
  result_vecNS[[i]] <- data.frame(rep_tmp[[i]]$result_tmp/global_para$rep, n, p, q, cov.type,"vecNS",
                                  mean(rep_tmp[[i]]$auc.vec), sd(rep_tmp[[i]]$auc.vec))
  colnames(result_vecNS[[i]]) <- c('lambda', 'vec_FP_rate', 'vec_TP_rate',
                                   'n','p','q','cov.type','method',"vec_AUC", "vec_AUC_sd")
}
end_time_vecNS = Sys.time()
elp_time_vecNS = end_time_vecNS - start_time_vecNS ; elp_time_vecNS
names(result_vecNS) <- apply(paragrid, 1, test_naming)


## method: vectorized glasso
n <- 0
p <- 0
q <- 0
U <- 0
V <- 0
cov.type <- 0
rep_tmp <- list()
result_vecgls <- list()
result_all = list()
result_tmp <- matrix(0, nrow=length(global_para$lambda), ncol=3)
auc_row_tmp <- c()
auc_col_tmp <- c()

start_time_vecgls <- Sys.time()
for(i in 1:nrow(paragrid)){
  ## data generation
  n = paragrid$n[i]
  p = paragrid$p[i]
  q = paragrid$q[i]
  cov.type = paragrid$type_graph[i]
  Uinv <- Covmat[["band"]](p,global_para$rho_band)
  Vinv <- Covmat[[cov.type]](q,paragrid$rho[i])
  U <- solve(Uinv)
  V <- solve(Vinv)
  cat("n=",n,", p=",p,", q=",q,", type=",cov.type,"\n",sep="")
  auc_row_tmp <- c()
  auc_col_tmp <- c()
  Sigmainv <- kronecker(Vinv,Uinv)
  
  set.seed(1234)
  rep_tmp[[i]] <- foreach(r = 1:global_para$rep, .packages = name_pkg, .combine = function(x, y){
    list(
      result_tmp = mysum(x$result_tmp, y$result_tmp),
      auc.vec = c(x$auc.vec, y$auc.vec)
    )
  }) %dopar% { 
    Xdata <- matnormgen(n,U,V)
    ## data analysis
    for(j in 1:length(global_para$lambda)){
      lam <- global_para$lambda[j]
      est_vecgls<-vecglassosel(Xdata,lam)
      eval_vecgls <- evalNS(est_vecgls,Sigmainv)
      result_tmp[j,1] <- lam
      result_tmp[j,2] <- eval_vecgls$false.positive.rate
      result_tmp[j,3] <- 1 - eval_vecgls$false.negative.rate
    }
    auc_vec_tmp = myAUC2(result_tmp[,2], result_tmp[,3])
    return(list(result_tmp = result_tmp, auc.vec = auc_vec_tmp))
  }
  result_vecgls[[i]] <- data.frame(rep_tmp[[i]]$result_tmp/global_para$rep, n, p, q, cov.type,"vecglasso",
                                  mean(rep_tmp[[i]]$auc.vec), sd(rep_tmp[[i]]$auc.vec))
  colnames(result_vecgls[[i]]) <- c('lambda', 'vec_FP_rate', 'vec_TP_rate',
                                   'n','p','q','cov.type','method',"vec_AUC", "vec_AUC_sd")
}
end_time_vecgls = Sys.time()
elp_time_vecgls = end_time_vecgls-start_time_vecgls ; elp_time_vecgls
names(result_vecgls) <- apply(paragrid, 1, test_naming)
stopCluster(cl)

time<-data.frame(c("matrixNS","GEMINI","Likelihood",
                   "vecNS","vecglasso"), c(elp_time, elp_time_GEM, elp_time_like, elp_time_vecNS, elp_time_vecgls))

save(
  list = c("result_NS",
           "result_GEM",
           "result_like",
           "result_vecNS",
           "result_vecgls",
           "paragrid", 
           "global_para",
           "time"),
  file = "Result_supp_fig4.RData")


## Result
res_vec <- rbind(do.call(rbind, result_NS), do.call(rbind, result_GEM), do.call(rbind, result_like),
  do.call(rbind, result_vecNS),do.call(rbind, result_vecgls))

res_vecauc <- res_vec %>%
  group_by(cov.type, p, q, method) %>%
  slice(1) %>%
  ungroup()

pdf(here("matrixNS_supp_fig4.pdf"), width = 6, height = 6)

ggplot(res_vec, aes(x =vec_FP_rate, y = vec_TP_rate, color = method)) +
  geom_line(data = dplyr::filter(res_vec, method == "vecNS" | method == "vecglasso"), alpha = 0.6) +
  geom_line(data = dplyr::filter(res_vec, method == "NS" | method == "GEMINI" | method == "Likelihood"), alpha = 1) +
  facet_grid(cov.type ~ p + q) + 
  labs( #title = "ROC curves for column selection (n=20, row=band, normal dist., rep=100)",
    x = "FPR",
    y = "TPR",
    color = "Method") +
  scale_color_manual(
    breaks = c("NS", "GEMINI","Likelihood", "vecNS", "vecglasso"),
    values = c(
      "NS"         = "black",
      "GEMINI"     = "red", 
      "Likelihood" = "blue",  
      "vecNS"      = "purple",
      "vecglasso"  = "#008080"
    ),
    guide = guide_legend(override.aes = list(alpha = c(1, 1, 1, 0.5,0.5)))
  ) +
  scale_x_continuous(limits = c(0, 0.15)) + 
  scale_y_continuous(limits = c(0, 1)) +
  theme_minimal() +
  geom_text(data = dplyr::filter(res_vecauc, method == "NS"), aes(x = 0.01, y = 0.5, label = paste0("NS: ", sprintf("%.3f", vec_AUC))),
            color = "black", size = 3, hjust = 0, vjust = 1)+
  geom_text(data = dplyr::filter(res_vecauc, method == "GEMINI"), aes(x = 0.01, y = 0.4, label = paste0("GEM: ", sprintf("%.3f", vec_AUC))),
            color = "red", size = 3, hjust = 0, vjust = 1)+
  geom_text(data = dplyr::filter(res_vecauc, method == "Likelihood"), aes(x = 0.01, y = 0.3, label = paste0("Like: ", sprintf("%.3f", vec_AUC))),
            color = "blue", size = 3, hjust = 0, vjust = 1)+
  geom_text(data = dplyr::filter(res_vecauc, method == "vecNS"), aes(x = 0.01, y = 0.2, label = paste0("vecNS: ", sprintf("%.3f", vec_AUC))),
            color = "purple", size = 3, hjust = 0, vjust = 1)+
  geom_text(data = dplyr::filter(res_vecauc, method == "vecglasso"), aes(x = 0.01, y = 0.1, label = paste0("vecglasso: ", sprintf("%.3f", vec_AUC))),
          color = "#008080", size = 3, hjust = 0, vjust = 1)

grid.text("p", x = unit(0.05, "npc"), y = unit(0.97, "npc"),
          gp = gpar(fontsize = 10, fontface = "bold"), just = "left")
grid.text("q", x = unit(0.05, "npc"), y = unit(0.93, "npc"),
          gp = gpar(fontsize = 10, fontface = "bold"), just = "left")
dev.off()


