rm(list = ls())
options(repos = c(CRAN = "http://cran.rstudio.com"))

##
global_para <- list(rep=1000, lambda =2^seq(-10,2,by=0.25),
                    rho_hub = 0.4, rho_band = 0.6, rho_rand = 0.4, t_df=5)
seed<-1234
n_cluster <- 9

## library ----------------------------------------------------------
name_pkg <- c(
  # Analysis
  "expm",
  "glasso",
  "glmnet",
  "mvtnorm",
  "tidyverse",
  # Parallelization
  "foreach",
  "doParallel",
  # Visualization
  "here",
  "ggplot2",
  "grid",
  "abind",
  "gridExtra"
)
name_pkg <- unique(name_pkg)
invisible(lapply(name_pkg, library, character.only = T)) #  multiple packages

## source ----------------------------------------------------------
setwd(here())
source(here("matrixNS_functions.R"))

## Simulation settings -----------------------------------------------------
paragrid <- expand.grid(
  n = c(20),
  p = c(20,50),
  q = c(20,50),
  type_graph = c("hub","band","random"),
  stringsAsFactors = FALSE
)
paragrid$rho <- NA
paragrid$rho[paragrid$type_graph == "hub"] <- global_para$rho_hub
paragrid$rho[paragrid$type_graph == "band"] <- global_para$rho_band
paragrid$rho[paragrid$type_graph == "band2"] <- global_para$rho_band
paragrid$rho[paragrid$type_graph == "random"] <- global_para$rho_rand
paragrid$rho[paragrid$type_graph == "identity"] <- 1

print(
  knitr::kable(paragrid, format = "simple", row.names = T)
)
paragrid_long <- paragrid[rep(1:nrow(paragrid), each = global_para$rep),,drop = F]

## Assign clusters for parallel computing ----------------------------------------------------------
cl <- makeCluster(n_cluster,
                  outfile = "Result_verbose.txt")
registerDoParallel(cl)

## Initialize --------------
n <- 0
p <- 0
q <- 0
U <- 0
V <- 0
cov.type <- 0
rep_tmp <- list()
result_NS2 <- list()
result_all = list()
result_tmp <- matrix(0, nrow=length(global_para$lambda), ncol=5)
auc_row_tmp <- c()
auc_col_tmp <- c()

## Timing (start) ----------------------------------------------------------
start_time <- Sys.time()
for(i in 1:nrow(paragrid)){
  ## data generation
  n = paragrid$n[i]
  p = paragrid$p[i]
  q = paragrid$q[i]
  cov.type = paragrid$type_graph[i]
  Uinv <- Covmat[["band"]](p,global_para$rho_band)
  Vinv <- Covmat[[cov.type]](q,paragrid$rho[i])
  mf <- runif(p+q, 1, 5)
  diag(Uinv) <- diag(Uinv) * mf[1:p]
  diag(Vinv) <- diag(Vinv) * mf[(p+1):(p+q)]
  U <- solve(Uinv)
  V <- solve(Vinv)
  cat("n=",n,", p=",p,", q=",q,", type=",cov.type,"\n",sep="")
  auc_row_tmp <- c()
  auc_col_tmp <- c()
  
  set.seed(seed)
  rep_tmp[[i]] <- foreach(r = 1:global_para$rep, .packages = name_pkg, .combine = function(x, y){
    list(
      result_tmp = mysum(x$result_tmp, y$result_tmp),
      auc.row = c(x$auc.row, y$auc.row),
      auc.col = c(x$auc.col, y$auc.col)
    )
  }) %dopar% { 
    Xdata <- matnormgen(n,U,V)
#    if(T){
#      library(abind)
#      mat_array <- abind(Xdata, along = 3)
#      mat_mean <- apply(mat_array, 1:2, mean)
#      mat_sd <- apply(mat_array, 1:2, sd)
#      Xdata_std <- lapply(Xdata, function(df) (df - mat_mean) / mat_sd)
#    }
    
    ## data analysis
    for(j in 1:length(global_para$lambda)){
      lam <- global_para$lambda[j]
      eval_rowNS_and <- evalNS(matrixrowNS(Xdata, lam)$and, Uinv)
      eval_colNS_and <- evalNS(matrixcolNS(Xdata, lam)$and, Vinv)
      result_tmp[j,1] <- lam
      result_tmp[j,2] <- eval_rowNS_and$false.positive.rate
      result_tmp[j,3] <- 1 - eval_rowNS_and$false.negative.rate
      result_tmp[j,4] <- eval_colNS_and$false.positive.rate
      result_tmp[j,5] <- 1 - eval_colNS_and$false.negative.rate
    }
    auc_row_tmp = myAUC2(result_tmp[,2], result_tmp[,3])
    auc_col_tmp = myAUC2(result_tmp[,4], result_tmp[,5])
    return(list(result_tmp = result_tmp, auc.row = auc_row_tmp, auc.col = auc_col_tmp))
  }
  result_NS2[[i]] <- data.frame(rep_tmp[[i]]$result_tmp/global_para$rep, n, p, q, cov.type,"NS",
                               mean(rep_tmp[[i]]$auc.row),sd(rep_tmp[[i]]$auc.row), mean(rep_tmp[[i]]$auc.col), sd(rep_tmp[[i]]$auc.col))
  colnames(result_NS2[[i]]) <- c('lambda', 'row_FP_rate', 'row_TP_rate', 'col_FP_rate', 'col_TP_rate',
                                'n','p','q','cov.type','method',"row_AUC", "row_AUC_sd", "col_AUC", "col_AUC_sd")
}
end_time = Sys.time()
elp_time = end_time-start_time ; elp_time
names(result_NS2) <- apply(paragrid, 1, test_naming)
stopCluster(cl)

## Result
load("Result_fig3.RData") ## You should run "matrixNS_fig3.R" first to load the main results!
res_total2 <- rbind(res_total, do.call(rbind,result_NS2) %>% mutate(method = "NS_stdX"))
res_total2$n <- factor(res_total2$n)
res_total2$p <- factor(res_total2$p)
res_total2$q <- factor(res_total2$q)
res_total2$cov.type <- factor(res_total2$cov.type)
res_total2$method <- factor(res_total2$method)

res_auc <- res_total2 %>%
  group_by(cov.type, p, q, method) %>%
  slice(1) %>%  # 첫 번째 행 선택
  ungroup()

method<-unique(res_total2$method)
save(
  list = c("res_total2",
           "paragrid", 
           "global_para" ),
  file = "Result_supp_fig5.RData")

## Visualize
graph_row <- ggplot(res_total2, aes(x = row_FP_rate, y = row_TP_rate, color = method)) +
  geom_line(data = dplyr::filter(res_total2, method == "NS"), alpha = 1) +
  geom_line(data = dplyr::filter(res_total2, method == "NS_stdX"), linewidth = 0.75, alpha = 0.6) +
  geom_line(data = dplyr::filter(res_total2, !method %in% c("NS", "NS_stdX")), alpha = 0.6) +
  facet_grid(cov.type ~ p + q) + 
  labs( #title = "ROC curves for row selection (n=20, row=band, normal dist., rep=100)",
       x = "FPR",
       y = "TPR",
       color = "Method") +
  scale_color_manual(
    breaks = c("NS", "NS_stdX", "GEMINI", "Likelihood"),
    values = c("NS" = "black", "NS_stdX" = "#008080", "GEMINI" = "red", "Likelihood" = "blue"),
    guide = guide_legend(override.aes = list(alpha = c(1, 0.5, 0.5, 0.5)))
  ) +
  scale_x_continuous(limits = c(0, 0.15)) + 
  theme_minimal() +
  geom_text(data = dplyr::filter(res_auc, method == "NS"), aes(x = 0.01, y = 0.4, label = paste0("NS: ", sprintf("%.3f", row_AUC), " (", sprintf("%.3f", row_AUC_sd),")")),
            color = "black", size = 3, hjust = 0, vjust = 1) +
  geom_text(data = dplyr::filter(res_auc, method == "NS_stdX"), aes(x = 0.01, y = 0.3, label = paste0("NS_stdX: ", sprintf("%.3f", row_AUC), " (", sprintf("%.3f", row_AUC_sd),")")),
            color = "#008080", size = 3, hjust = 0, vjust = 1) +
  geom_text(data = dplyr::filter(res_auc, method == "GEMINI"), aes(x = 0.01, y = 0.2, label = paste0("GEM: ", sprintf("%.3f", row_AUC), " (", sprintf("%.3f", row_AUC_sd),")")),
            color = "red", size = 3, hjust = 0, vjust = 1) +
  geom_text(data = dplyr::filter(res_auc, method == "Likelihood"), aes(x = 0.01, y = 0.1, label = paste0("Like: ", sprintf("%.3f", row_AUC), " (", sprintf("%.3f", row_AUC_sd),")")),
            color = "blue", size = 3, hjust = 0, vjust = 1) 

graph_col <- ggplot(res_total2, aes(x =col_FP_rate, y = col_TP_rate, color = method)) +
  geom_line(data = dplyr::filter(res_total2, method == "NS"), alpha = 1) +
  geom_line(data = dplyr::filter(res_total2, method == "NS_stdX"), linewidth = 0.75, alpha = 0.6) +
  geom_line(data = dplyr::filter(res_total2, !method %in% c("NS", "NS_stdX")), alpha = 0.6) +
  facet_grid(cov.type ~ p + q) + 
  labs( #title = "ROC curves for row selection (n=20, row=band, normal dist., rep=100)",
    x = "FPR",
    y = "TPR",
    color = "Method") +
  scale_color_manual(
    breaks = c("NS", "NS_stdX", "GEMINI", "Likelihood"),
    values = c("NS" = "black", "NS_stdX" = "#008080", "GEMINI" = "red", "Likelihood" = "blue"),
    guide = guide_legend(override.aes = list(alpha = c(1, 0.5, 0.5, 0.5)))
  ) +
  scale_x_continuous(limits = c(0, 0.15)) + 
  theme_minimal() +
  geom_text(data = dplyr::filter(res_auc, method == "NS"), aes(x = 0.01, y = 0.4, label = paste0("NS: ", sprintf("%.3f", col_AUC), " (", sprintf("%.3f", col_AUC_sd),")")),
            color = "black", size = 3, hjust = 0, vjust = 1) +
  geom_text(data = dplyr::filter(res_auc, method == "NS_stdX"), aes(x = 0.01, y = 0.3, label = paste0("NS_stdX: ", sprintf("%.3f", col_AUC), " (", sprintf("%.3f", col_AUC_sd),")")),
            color = "#008080", size = 3, hjust = 0, vjust = 1) +
  geom_text(data = dplyr::filter(res_auc, method == "GEMINI"), aes(x = 0.01, y = 0.2, label = paste0("GEM: ", sprintf("%.3f", col_AUC), " (", sprintf("%.3f", col_AUC_sd),")")),
            color = "red", size = 3, hjust = 0, vjust = 1) +
  geom_text(data = dplyr::filter(res_auc, method == "Likelihood"), aes(x = 0.01, y = 0.1, label = paste0("Like: ", sprintf("%.3f", col_AUC), " (", sprintf("%.3f", col_AUC_sd),")")),
            color = "blue", size = 3, hjust = 0, vjust = 1)

pdf(here("matrixNS_supp_fig5.pdf"), width = 18, height = 8)

grid.arrange(graph_row, graph_col, ncol = 2)

grid.text("p", x = unit(0.03, "npc"), y = unit(0.976, "npc"),
          gp = gpar(fontsize = 10, fontface = "bold"), just = "left")
grid.text("q", x = unit(0.03, "npc"), y = unit(0.946, "npc"),
          gp = gpar(fontsize = 10, fontface = "bold"), just = "left")
grid.text("p", x = unit(0.53, "npc"), y = unit(0.976, "npc"),
          gp = gpar(fontsize = 10, fontface = "bold"), just = "left")
grid.text("q", x = unit(0.53, "npc"), y = unit(0.946, "npc"),
          gp = gpar(fontsize = 10, fontface = "bold"), just = "left")

dev.off()
