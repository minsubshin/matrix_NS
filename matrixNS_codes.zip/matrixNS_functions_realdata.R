
NSgraphrow <- function(data, lambda){
  lam_NS_row <- lambda
  est_Uinv_NS <- matrixrowNS(data,lam_NS_row)$and
  sparsity <- (sum(est_Uinv_NS)-64)/(64*63)
  
  graph_row_NS <- igraph::graph_from_adjacency_matrix(est_Uinv_NS, mode = "undirected", diag = FALSE)
  V(graph_row_NS)$name <- electro
  V(graph_row_NS)[V(graph_row_NS)$name %in% electro1]$group <- 1
  V(graph_row_NS)[V(graph_row_NS)$name %in% electro2]$group <- 2
  V(graph_row_NS)[V(graph_row_NS)$name %in% electro3]$group <- 3
  V(graph_row_NS)[group == 1]$color <- "lightblue"
  V(graph_row_NS)[group == 2]$color <- "green"
  V(graph_row_NS)[group == 3]$color <- "pink"
  graph_row_NS_61 <- delete_vertices(graph_row_NS, V(graph_row_NS)$name %in% c("X","Y","nd"))
  eeg_layout_61 <- eeg_layout[!apply(eeg_layout, 1, function(row) all(is.na(row))), ]
  plot(graph_row_NS_61, layout = eeg_layout_61,
       vertex.shape = "circle", vertex.size = 12,
       vertex.label.cex = 0.7, 
       edge.width = 1, edge.color = "black", vertex.label.family = "sans", vertex.label.font = 2)
  
  mtext(paste0("Connectivity level: ", round(sparsity, 3)), side = 1, line = 0.5, cex = 1, font = 2)
  
  return(list(precision = est_Uinv_NS, plot = recordPlot(), sparsity = sparsity))
}


GEMgraphrow <- function(data, lambda){
  data_matrix <- lapply(data, as.matrix)
  lam_GEM_row <- lambda
  est_Uinv_GEM <- GeminirowNS(data_matrix,lam_GEM_row)
  sparsity <- (sum(est_Uinv_GEM)-64)/(64*63)
  graph_row_GEM <- igraph::graph_from_adjacency_matrix(est_Uinv_GEM, mode = "undirected", diag = FALSE)
  V(graph_row_GEM)$name <- electro
  V(graph_row_GEM)[V(graph_row_GEM)$name %in% electro1]$group <- 1
  V(graph_row_GEM)[V(graph_row_GEM)$name %in% electro2]$group <- 2
  V(graph_row_GEM)[V(graph_row_GEM)$name %in% electro3]$group <- 3
  V(graph_row_GEM)[group == 1]$color <- "lightblue"
  V(graph_row_GEM)[group == 2]$color <- "green"
  V(graph_row_GEM)[group == 3]$color <- "pink"
  graph_row_GEM_61 <- delete_vertices(graph_row_GEM, V(graph_row_GEM)$name %in% c("X","Y","nd"))
  eeg_layout_61 <- eeg_layout[!apply(eeg_layout, 1, function(row) all(is.na(row))), ]
  plot(graph_row_GEM_61, layout = eeg_layout_61,
       vertex.shape = "circle", vertex.size = 12,
       vertex.label.cex = 0.7, 
       edge.width = 1, edge.color = "black", vertex.label.family = "sans", vertex.label.font = 2)
  
  mtext(paste0("Connectivity level: ", round(sparsity, 3)), side = 1, line = 0.5, cex = 1, font = 2)
  
  return(list(precision = est_Uinv_GEM, plot = recordPlot(), sparsity = sparsity))
}

Likegraphrow <- function(data, lambdarow, Vinv.ref){
  data_matrix <- lapply(data, as.matrix)
  est_Uinv_like <- LikeNS_row(data_matrix,Vinv.ref,lambdarow)
  est_Uinv_like_row <- est_Uinv_like$row
  est_Uinv_like_col <- est_Uinv_like$col
  sparsity <- (sum(est_Uinv_like_row)-64)/(64*63)
  graph_row_like <- igraph::graph_from_adjacency_matrix(est_Uinv_like_row, mode = "undirected", diag = FALSE)
  V(graph_row_like)$name <- electro
  V(graph_row_like)[V(graph_row_like)$name %in% electro1]$group <- 1
  V(graph_row_like)[V(graph_row_like)$name %in% electro2]$group <- 2
  V(graph_row_like)[V(graph_row_like)$name %in% electro3]$group <- 3
  V(graph_row_like)[group == 1]$color <- "lightblue"
  V(graph_row_like)[group == 2]$color <- "green"
  V(graph_row_like)[group == 3]$color <- "pink"
  graph_row_like_61 <- delete_vertices(graph_row_like, V(graph_row_like)$name %in% c("X","Y","nd"))
  eeg_layout_61 <- eeg_layout[!apply(eeg_layout, 1, function(row) all(is.na(row))), ]
  plot(graph_row_like_61, layout = eeg_layout_61,
       vertex.shape = "circle", vertex.size = 12,
       vertex.label.cex = 0.7, 
       edge.width = 1, edge.color = "black", vertex.label.family = "sans", vertex.label.font = 2)
  
  mtext(paste0("Connectivity level: ", round(sparsity, 3)), side = 1, line = 0.5, cex = 1, font = 2)
  
  return(list(precision = est_Uinv_like, plot = recordPlot(), sparsity = sparsity))
}

Likegraphrow_lam <- function(data, lamrow, lamcol){
  data_matrix <- lapply(data, as.matrix)
  est_Uinv_Like <- LikeNS(data_matrix,lamrow, lamcol)$row
  sparsity <- (sum(est_Uinv_Like)-64)/(64*63)
  graph_row_Like <- igraph::graph_from_adjacency_matrix(est_Uinv_Like, mode = "undirected", diag = FALSE)
  V(graph_row_Like)$name <- electro
  V(graph_row_Like)[V(graph_row_Like)$name %in% electro1]$group <- 1
  V(graph_row_Like)[V(graph_row_Like)$name %in% electro2]$group <- 2
  V(graph_row_Like)[V(graph_row_Like)$name %in% electro3]$group <- 3
  V(graph_row_Like)[group == 1]$color <- "lightblue"
  V(graph_row_Like)[group == 2]$color <- "green"
  V(graph_row_Like)[group == 3]$color <- "pink"
  graph_row_Like_61 <- delete_vertices(graph_row_Like, V(graph_row_Like)$name %in% c("X","Y","nd"))
  eeg_layout_61 <- eeg_layout[!apply(eeg_layout, 1, function(row) all(is.na(row))), ]
  plot(graph_row_Like_61, layout = eeg_layout_61,
       vertex.shape = "circle", vertex.size = 12,
       vertex.label.cex = 0.7, 
       edge.width = 1, edge.color = "black", vertex.label.family = "sans", vertex.label.font = 2)
  
  mtext(paste0("Connectivity level: ", round(sparsity, 3)), side = 1, line = 0.5, cex = 1, font = 2)
  
  return(list(precision = est_Uinv_Like, plot = recordPlot(), sparsity = sparsity, graph=graph_row_Like))
}


## connectivity
connectivity<- function(graph){
  V(graph)$name <- electro
  V(graph)[V(graph)$name %in% electro1]$group <- 1
  V(graph)[V(graph)$name %in% electro2]$group <- 2
  V(graph)[V(graph)$name %in% electro3]$group <- 3
  internal_ratio_group1 <- sum(apply(ends(graph, E(graph)), 1, 
                                     function(e) all(e %in% electro1))) / 
    (length(electro1) * (length(electro1) - 1) / 2)
  
  internal_ratio_group2 <- sum(apply(ends(graph, E(graph)), 1, 
                                     function(e) all(e %in% electro2))) / 
    (length(electro2) * (length(electro2) - 1) / 2)
  
  internal_ratio_group3 <- sum(apply(ends(graph, E(graph)), 1, 
                                     function(e) all(e %in% electro3))) / 
    (length(electro3) * (length(electro3) - 1) / 2)
  
  ratio_group1_2 <- sum(apply(ends(graph, E(graph)), 1, 
                              function(e) (e[1] %in% electro1 & e[2] %in% electro2) | 
                                (e[1] %in% electro2 & e[2] %in% electro1))) / 
    (length(electro1) * length(electro2))
  
  ratio_group2_3 <- sum(apply(ends(graph, E(graph)), 1, 
                              function(e) (e[1] %in% electro2 & e[2] %in% electro3) | 
                                (e[1] %in% electro3 & e[2] %in% electro2))) / 
    (length(electro2) * length(electro3))
  
  ratio_group3_1 <- sum(apply(ends(graph, E(graph)), 1, 
                              function(e) (e[1] %in% electro3 & e[2] %in% electro1) | 
                                (e[1] %in% electro1 & e[2] %in% electro3))) / 
    (length(electro3) * length(electro1))
  
  cat("Internal Edge Ratios (within each group):\n")
  cat(sprintf("Group 1: %.3f\n", internal_ratio_group1))
  cat(sprintf("Group 2: %.3f\n", internal_ratio_group2))
  cat(sprintf("Group 3: %.3f\n", internal_ratio_group3))
  
  cat("\nBetween Group Edge Ratios:\n")
  cat(sprintf("Group 1 - Group 2: %.3f\n", ratio_group1_2))
  cat(sprintf("Group 2 - Group 3: %.3f\n", ratio_group2_3))
  cat(sprintf("Group 3 - Group 1: %.3f\n", ratio_group3_1))
}