rm(list = ls())
options(repos = c(CRAN = "http://cran.rstudio.com"))

global_para <- list(rep=100, lambda =2^seq(-10,2,by=0.25),
                    rho_hub = 0.2, rho_band = 0.3, rho_rand = 0.2, t_df=5)
seed<-1234

## library ----------------------------------------------------------
name_pkg <- c(
  # Analysis
  "expm",
  "glasso",
  "glmnet",
  "mvtnorm",
  "tidyverse",
  # Parallelization
  "foreach",
  "doParallel",
  # Visualization
  "here",
  "ggplot2",
  "grid",
  "abind",
  "gridExtra"
)
name_pkg <- unique(name_pkg)
invisible(lapply(name_pkg, library, character.only = T)) # load multiple packages

## source ----------------------------------------------------------
setwd(here())
source(here("matrixNS_functions.R"))

dim <- c(20,50,100,200)
time<-list()

for(d in 1:4){
  paragrid <- expand.grid(
    n = c(20),
    p = c(dim[d]),
    q = c(dim[d]),
    type_graph = c("hub","band","random"),
    stringsAsFactors = FALSE
  )
  paragrid$rho <- NA
  paragrid$rho[paragrid$type_graph == "hub"] <- global_para$rho_hub
  paragrid$rho[paragrid$type_graph == "band"] <- global_para$rho_band
  paragrid$rho[paragrid$type_graph == "random"] <- global_para$rho_rand
  paragrid$rho[paragrid$type_graph == "identity"] <- 1
  
  print(
    knitr::kable(paragrid, format = "simple", row.names = T)
  )
  
  ## Initialize --------------
  n <- paragrid$n[1]
  p <- paragrid$p[1]
  q <- paragrid$q[1]
  Uinv <- list()
  Vinv <- list()
  U <- list()
  V <- list()
  cov.type <- 0
  rep_tmp <- list()
  result_NS <- list()
  result_all = list()
  result_tmp <- matrix(0, nrow=length(global_para$lambda), ncol=5)
  
  ## Setup
  for(i in 1:nrow(paragrid)){
  cov.type = paragrid$type_graph[i]
  Uinv[[i]] <- Covmat[["band"]](p,global_para$rho_band)
  Vinv[[i]] <- Covmat[[cov.type]](q,paragrid$rho[i])
  U[[i]] <- solve(Uinv[[i]])
  V[[i]] <- solve(Vinv[[i]])
  }
  
  ## Timing (start) ----------------------------------------------------------
  set.seed(1234)
  total_elp_time <- as.difftime(0, units = "secs")
  total_elp_time_GEM <- as.difftime(0, units = "secs")
  total_elp_time_like <- as.difftime(0, units = "secs")
  total_elp_time_vecNS <- as.difftime(0, units = "secs")
  total_elp_time_vecglasso <- as.difftime(0, units = "secs")
  
  for(i in 1:nrow(paragrid)){
    cat("n=",n,", p=",p,", q=",q,", type=",paragrid$type_graph[i],"\n",sep="")
    Xdata <- matnormgen(n, U[[i]], V[[i]])
    Xdata_t <- lapply(Xdata, t)
    
      for(r in 1:global_para$rep){
        cat("rep=", r, "\n", sep="")
        start_time <- Sys.time()
        res_row <- matrixcolNS(Xdata, global_para$lambda)
        res_col <- matrixcolNS(Xdata_t, global_para$lambda)
        end_time = Sys.time()
        elp_time = end_time-start_time
        total_elp_time <- total_elp_time + elp_time
        
        ## method: GEMINI
        start_time_GEM <- Sys.time()
        res_row <- GeminirowNS_SP(Xdata, global_para$lambda)
        res_col <- GeminirowNS_SP(Xdata_t, global_para$lambda)
        end_time_GEM = Sys.time()
        elp_time_GEM = end_time_GEM-start_time_GEM
        total_elp_time_GEM <- total_elp_time_GEM + elp_time_GEM    
      }
  }
  
  ## method: Likelihood flip-flop
  set.seed(1234)
  for(i in 1:nrow(paragrid)){
    cat("n=",n,", p=",p,", q=",q,", type=",paragrid$type_graph[i],"\n",sep="")
    
    for(r in 1:global_para$rep){
      cat("like rep=", r, "\n", sep="")
      Xdata <- matnormgen(n,U[[i]],V[[i]])
      start_time_like <- Sys.time()
      for(j in 1:length(global_para$lambda)){
        lam<-global_para$lambda[j]
        res_row <- LikeNS(Xdata,lam,2^(-2))$row
        res_col<- LikeNS(Xdata,2^(-2),lam)$col
      }
      end_time_like = Sys.time()
      elp_time_like = end_time_like - start_time_like
      total_elp_time_like <- total_elp_time_like + elp_time_like
    }
  }
  
  time[[d]] <- data.frame(c("matrixNS","GEMINI","Likelihood"), c(total_elp_time, total_elp_time_GEM, total_elp_time_like))
}

save(
  list = c("time"),
  file = "Result_table1.RData")


