rm(list = ls())
options(repos = c(CRAN = "http://cran.rstudio.com"))

global_para <- list(rep=1000, lambda =2^seq(-10,2,by=0.25),
                    rho_hub = 0.4, rho_band = 0.6, rho_rand = 0.4, t_df=5)
seed<-1234
n_cluster <- 9

## library ----------------------------------------------------------
name_pkg <- c(
  # Analysis
  "expm",
  "glasso",
  "glmnet",
  "mvtnorm",
  "tidyverse",
  # Parallelization
  "foreach",
  "doParallel",
  # Visualization
  "here",
  "ggplot2",
  "grid",
  "abind",
  "gridExtra"
)
name_pkg <- unique(name_pkg)
invisible(lapply(name_pkg, library, character.only = T)) # load multiple packages

## source ----------------------------------------------------------
setwd(here())
source(here("matrixNS_functions.R"))

## Simulation settings -----------------------------------------------------
paragrid <- expand.grid(
  n = c(20),
  p = c(20,50),
  q = c(20,50),
  type_graph = c("hub","band","random"),
  stringsAsFactors = FALSE
)
paragrid$rho <- NA
paragrid$rho[paragrid$type_graph == "hub"] <- global_para$rho_hub
paragrid$rho[paragrid$type_graph == "band"] <- global_para$rho_band
paragrid$rho[paragrid$type_graph == "random"] <- global_para$rho_rand
paragrid$rho[paragrid$type_graph == "identity"] <- 1

print(
  knitr::kable(paragrid, format = "simple", row.names = T)
)
paragrid_long <- paragrid[rep(1:nrow(paragrid), each = global_para$rep),,drop = F]


## Assign clusters for parallel computing ----------------------------------------------------------
cl <- makeCluster(n_cluster,
                  outfile = "Result_verbose.txt")
registerDoParallel(cl)

## Initialize --------------
n <- 0
p <- 0
q <- 0
U <- 0
V <- 0
cov.type <- 0
rep_tmp <- list()
result_NS <- list()
result_all = list()
result_tmp <- matrix(0, nrow=length(global_para$lambda), ncol=5)
auc_row_tmp <- c()
auc_col_tmp <- c()
result_indtun <- c()
result_NS_indtun <- list()

## Timing (start) ----------------------------------------------------------
start_time <- Sys.time()
for(i in 1:nrow(paragrid)){
  ## data generation
  n = paragrid$n[i]
  p = paragrid$p[i]
  q = paragrid$q[i]
  cov.type = paragrid$type_graph[i]
  Uinv <- Covmat[["band"]](p,global_para$rho_band)
  Vinv <- Covmat[[cov.type]](q,paragrid$rho[i])
  mf <- runif(p+q, 1, 5)
  diag(Uinv) <- diag(Uinv) * mf[1:p]
  diag(Vinv) <- diag(Vinv) * mf[(p+1):(p+q)]
  U <- solve(Uinv)
  V <- solve(Vinv)
  cat("n=",n,", p=",p,", q=",q,", type=",cov.type,"\n",sep="")
  auc_row_tmp <- c()
  auc_col_tmp <- c()
  
  set.seed(1234)
  rep_tmp[[i]] <- foreach(r = 1:global_para$rep, .packages = name_pkg, .combine = function(x, y){
    list(
      result_tmp = mysum(x$result_tmp, y$result_tmp),
      auc.row = c(x$auc.row, y$auc.row),
      auc.col = c(x$auc.col, y$auc.col),
      result_indtun = mysum(x$result_indtun, y$result_indtun)
    )
  }) %dopar% { 
    Xdata <- matnormgen(n,U,V)
    Xdata_t <- lapply(Xdata, t)
    for(j in 1:length(global_para$lambda)){
      lam <- global_para$lambda[j]
      eval_rowNS_and <- evalNS(matrixrowNS(Xdata, lam)$and, Uinv)
      eval_colNS_and <- evalNS(matrixcolNS(Xdata, lam)$and, Vinv)
      result_tmp[j,1] <- lam
      result_tmp[j,2] <- eval_rowNS_and$false.positive.rate
      result_tmp[j,3] <- 1 - eval_rowNS_and$false.negative.rate
      result_tmp[j,4] <- eval_colNS_and$false.positive.rate
      result_tmp[j,5] <- 1 - eval_colNS_and$false.negative.rate
    }
    auc_row_tmp = myAUC2(result_tmp[,2], result_tmp[,3])
    auc_col_tmp = myAUC2(result_tmp[,4], result_tmp[,5])
    
    eval_rowNS_indtun <- evalNS(matrixcolNS_cv(Xdata_t, global_para$lambda)$and, Uinv)
    eval_colNS_indtun <- evalNS(matrixcolNS_cv(Xdata, global_para$lambda)$and, Vinv)
    result_indtun <- c(0, eval_rowNS_indtun$false.positive.rate, 1-eval_rowNS_indtun$false.negative.rate,
                       eval_colNS_indtun$false.positive.rate, 1 - eval_colNS_indtun$false.negative.rate)
    return(list(result_tmp = result_tmp, auc.row = auc_row_tmp, auc.col = auc_col_tmp, result_indtun=result_indtun))
  }
  result_NS[[i]] <- data.frame(rep_tmp[[i]]$result_tmp/global_para$rep, n, p, q, cov.type,"NS",
                               mean(rep_tmp[[i]]$auc.row),sd(rep_tmp[[i]]$auc.row), mean(rep_tmp[[i]]$auc.col), sd(rep_tmp[[i]]$auc.col))
  colnames(result_NS[[i]]) <- c('lambda', 'row_FP_rate', 'row_TP_rate', 'col_FP_rate', 'col_TP_rate',
                                'n','p','q','cov.type','method',"row_AUC", "row_AUC_sd", "col_AUC", "col_AUC_sd")
  result_NS_indtun[[i]] <- data.frame(t(c('optimal lambda',rep_tmp[[i]]$result_indtun[2:5]/global_para$rep,
                                      n, p, q, cov.type, "NS")))
  colnames(result_NS_indtun[[i]]) <- c('lambda', 'row_FP_rate', 'row_TP_rate', 'col_FP_rate', 'col_TP_rate',
                                'n','p','q','cov.type','method')
}
end_time = Sys.time()
elp_time = end_time-start_time ; elp_time
names(result_NS) <- apply(paragrid, 1, test_naming)
stopCluster(cl)

## Result
res_total<-do.call(rbind, result_NS)
# If you have loaded .Rdata file, then start from here:
res_total$n <- factor(res_total$n)
res_total$p <- factor(res_total$p)
res_total$q <- factor(res_total$q)
res_total$cov.type <- factor(res_total$cov.type)
res_total$method <- factor(res_total$method)

res_auc <- res_total %>%
  group_by(cov.type, p, q, method) %>%
  slice(1) %>%  # 첫 번째 행 선택
  ungroup()

res_NS <- res_total %>% dplyr::filter(method=="NS")
res_NS$n <- factor(res_NS$n)
res_NS$p <- factor(res_NS$p)
res_NS$q <- factor(res_NS$q)
res_NS$cov.type <- factor(res_NS$cov.type)
res_indtun_df <- do.call(rbind, result_NS_indtun)
res_indtun_df$p <- factor(res_indtun_df$p)
res_indtun_df$q <- factor(res_indtun_df$q)
res_indtun_df$cov.type <- factor(res_indtun_df$cov.type)
res_indtun_df[,2:5] <- lapply(res_indtun_df[,2:5], as.numeric)

res_auc <- res_NS %>%
  group_by(cov.type, p, q) %>%
  slice(1) %>%
  ungroup()

save(
  list = c("res_total",
           "paragrid", 
           "global_para", "result_NS_indtun" ),
  file = "Result_fig4.RData")

## Visualize
graph_row <- ggplot(res_NS, aes(x = row_FP_rate, y = row_TP_rate)) +
  geom_line(data = dplyr::filter(res_NS, method != "NS"), alpha = 0.6) +
  geom_line(data = dplyr::filter(res_NS, method == "NS"), alpha = 1) +
  facet_grid(cov.type ~ p + q) + 
  labs(x = "FPR", y = "TPR") +
  scale_x_continuous(limits = c(0, 0.5)) + 
  theme_minimal() +
  geom_text(data = dplyr::filter(res_auc, method == "NS"),
            aes(x = 0.01, y = 0.1, label = paste0("NS: ", sprintf("%.3f", row_AUC), " (", sprintf("%.3f", row_AUC_sd), ")")),
            color = "black", size = 3, hjust = 0, vjust = 1) +
  geom_point(data = res_indtun_df, aes(x = row_FP_rate, y = row_TP_rate), color = "blue", size = 2)

graph_col <- ggplot(res_NS, aes(x = col_FP_rate, y = col_TP_rate)) +
  geom_line(data = dplyr::filter(res_NS, method != "NS"), alpha = 0.6) +
  geom_line(data = dplyr::filter(res_NS, method == "NS"), alpha = 1) +
  facet_grid(cov.type ~ p + q) + 
  labs(x = "FPR", y = NULL) +
  scale_x_continuous(limits = c(0, 0.5)) + 
  theme_minimal() +
  geom_text(data = dplyr::filter(res_auc, method == "NS"),
            aes(x = 0.01, y = 0.1, label = paste0("NS: ", sprintf("%.3f", col_AUC), " (", sprintf("%.3f", col_AUC_sd), ")")),
            color = "black", size = 3, hjust = 0, vjust = 1) +
  geom_point(data = res_indtun_df, aes(x = col_FP_rate, y = col_TP_rate), color = "blue", size = 2)

pdf(here("matrixNS_fig4.pdf"), width = 18, height = 8)

grid.arrange(graph_row, graph_col, ncol = 2)

grid.text("p", x = unit(0.03, "npc"), y = unit(0.976, "npc"),
          gp = gpar(fontsize = 10, fontface = "bold"), just = "left")
grid.text("q", x = unit(0.03, "npc"), y = unit(0.946, "npc"),
          gp = gpar(fontsize = 10, fontface = "bold"), just = "left")
grid.text("p", x = unit(0.53, "npc"), y = unit(0.976, "npc"),
          gp = gpar(fontsize = 10, fontface = "bold"), just = "left")
grid.text("q", x = unit(0.53, "npc"), y = unit(0.946, "npc"),
          gp = gpar(fontsize = 10, fontface = "bold"), just = "left")
dev.off()




