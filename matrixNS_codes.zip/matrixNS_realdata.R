rm(list = ls())
options(repos = c(CRAN = "http://cran.rstudio.com"))

## library ----------------------------------------------------------
library(sand)
library(igraphdata)
library(eegkit)
library(glasso)
library(gridExtra)
library(glmnet)
library(here)

## source ----------------------------------------------------------
setwd(here())
source("./matrixNS_functions.R")
source("./matrixNS_functions_realdata.R")

## Data import
i = 1
path <- c("c_1_co2c0000337", "c_m_co2c0000337", "c_n_co2c0000337")
file_name <- list.files(path = paste0("eegsample/", path[i]))
data_org <- vector(mode = "list", length = length(file_name))
for(j in 1:length(file_name)){
  temp <- read.table(gzfile(paste0("eegsample/", path[i], "/", file_name[j])))
  tempcent <- temp$V4
  data_org[[j]] <- as.data.frame(matrix(tempcent, nrow = 64, ncol = 256, byrow = T))
  rownames(data_org[[j]]) <- unique(temp$V2)
}

## Pre-processing
combined_mean <- Reduce("+", data_org) / length(data_org)
combined_sd <- sqrt(Reduce("+", lapply(data_org, function(df) (df - combined_mean)^2)) / length(data_org))
data <- lapply(data_org, function(df) (df - combined_mean) / combined_sd)
data_matrix <- lapply(data, as.matrix)
data_center <- lapply(data_org, function(df) df - combined_mean)
data_center_matrix <- lapply(data_center, as.matrix)

electro <- rownames(data[[1]])
electro1 <- c("C2", "C4", "FC6", "C6", "CP6", "CP4","FC4","T8","P4","P2","CP2","PO2","P6","P8","O2",
              "TP8","FC2","F4","FT8","F8","F6","AF2","F2","AF8","FP2","PO8")
electro2 <- c("POZ","PZ","OZ","CPZ","FCZ","CZ","Y","AFZ","FZ","X","nd","FPZ")
electro3 <- setdiff(electro, union(electro1, electro2))

data(eegcoord)
eeg_sorted <- eegcoord[electro, 4:5]
rownames(eeg_sorted) <- electro
eeg_layout <- as.matrix(eeg_sorted)


## Spatial graph (Fig. 5)
lam <- c(0.0182, 0.0313, 0.1768)
lam2 <- c(0.15, 0.66, 0.82)
lam3 <- c(0.95,1.07,1.16)

pdf(file = "matrixNS_fig5.pdf", width = 13, height = 13)
par(mfrow = c(3, 3), mar = c(2, 2, 1, 1), oma = c(1, 1, 1, 1))

all_plots <- vector("list", length = 3 * length(lam))

for(i in seq_along(lam)){
  NSgraphrow(data,lam[i])
  all_plots[[3*i - 2]] <- recordPlot()
  
  GEMgraphrow(data,lam2[i])
  all_plots[[3*i - 1]] <- recordPlot()
  
  Likegraphrow_lam(data,0.4,lam3[i])
  all_plots[[3*i]] <- recordPlot()
}

for(p in all_plots) {
  replayPlot(p)
}

dev.off()

## connectivity level (Table 2)
NS01 <- igraph::graph_from_adjacency_matrix(NSgraphrow(data,0.0313)$precision, mode = "undirected", diag = FALSE)
GEM01 <- igraph::graph_from_adjacency_matrix(GEMgraphrow(data,0.66)$precision, mode = "undirected", diag = FALSE)
Like01 <- igraph::graph_from_adjacency_matrix(Likegraphrow_lam(data,0.4,1.07)$precision, mode = "undirected", diag = FALSE)
connectivity(NS01)
connectivity(GEM01)
connectivity(Like01)


## Temporal graph (Fig. 6)
lam_NS_col <- 2^(-2) ## Choose lambda which gives similar connectivity level to GEMINI
est_Vinv_NS <- matrixcolNS(data,lam_NS_col)$and
graph_col_NS <- igraph::graph_from_adjacency_matrix(est_Vinv_NS, mode = "undirected", diag = FALSE)
grid_layout <- cbind(rep(c(1:16,16:1),8),rep(16:1, each=16))

lam_GEM_row <- 0.4
lam_GEM_col <- 0.78
est_Vinv_GEM <- GeminicolNS(data_matrix,lam_GEM_col)
graph_col_GEM <- igraph::graph_from_adjacency_matrix(est_Vinv_GEM, mode = "undirected", diag = FALSE)

pdf(file = "matrixNS_fig6.pdf", width = 16, height = 7)
par(mfrow=c(1,2), mar = c(2, 2, 2, 2))
plot(graph_col_NS, layout = grid_layout, vertex.size = 0, vertex.label = 1:256, 
     vertex.label.cex = 0.8, vertex.label.color = "black", vertex.frame.color = NA, 
     vertex.label.family = "mono", edge.width=2)
plot(graph_col_GEM, layout = grid_layout, vertex.size = 0, vertex.label = 1:256, 
     vertex.label.cex = 0.8, vertex.label.color = "black", vertex.frame.color = NA, 
     vertex.label.family = "mono", edge.width=2)
dev.off()
