## Covariance matrix generation
Covmat <- list(
  "hub"=function(p,rho = 0.5){
    Sig1 <- diag(p)
    kmax=round(p/10)
    for(k in 1:kmax){
      i <- 10*(k-1)+1
      jmin <- 10*(k-1)+2
      jmax <- 10*k
      for(j in jmin:jmax){
        Sig1[i,j] <- rho
        Sig1[j,i] <- rho
      }
    }
    eigenmin = abs(min(eigen(Sig1)$values))
    Sig = Sig1+ (eigenmin+0.05)*diag(p)
    return(Sig)
  },
  "band"=function(p,rho = 0.4){
    Sig <- diag(p)
    for(i in 1:(p-1)){
      Sig[i,i+1] <- rho
      Sig[i+1,i] <- rho
    }
    for(i in 1:(p-2)){
      Sig[i,i+2] <- rho/2
      Sig[i+2,i] <- rho/2
    }
    return(Sig)
  },
  "random"=function(p,rho = 0.4){
    Sig1 <- diag(p)
    prob <- min(0.05,5/p)
    u <- runif(p*(p-1)/2,min=rho, max=rho)
    delta <- rbinom(p*(p-1)/2, size=1, prob)
    index <- 1
    for(i in 1:(p-1)){
      for(j in (i+1):p){
        Sig1[i,j] <- (u*delta)[index]
        Sig1[j,i] <- (u*delta)[index]
        index <- index + 1
      }
    }
    eigenmin = abs(min(eigen(Sig1)$values))
    Sig = Sig1+ (eigenmin+0.05)*diag(p)
    return(Sig)
  },
  "identity"=function(p, rho1){
    return(diag(p))
  },
  "band2"=function(p,rho = 0.4){
    Sig <- diag(p)
    q <- floor(p/2)-2
    for(i in 1:(p-1)){
      Sig[i,i+1] <- rho
      Sig[i+1,i] <- rho
    }
    for(i in 1:q){
      Sig[i,i+2] <- rho/2
      Sig[i+2,i] <- rho/2
    }
    for(i in 1:(q-1)){
      Sig[i,i+3] <- rho/4
      Sig[i+3,i] <- rho/4
    }
    return(Sig)
  }
)

SparsityLev = function(Est){
  nonzerocount <- function(x) {
  return (sum(abs(x) > 10^(-10)))
  }
  s1 <- apply(Est, 1, nonzerocount)
  return(max(s1))
}

## Generate n copy of matrix normal data
matnormgen <- function(n, U, V){
  sqrtU <- sqrtm(U)
  sqrtV <- sqrtm(V)
  p <- dim(U)[1]
  q <- dim(V)[1]
  X<-list()
  for(i in 1:n){
    Xvec = rnorm(p*q, mean=0, sd=1)
    X[[i]] <- sqrtU %*% matrix(Xvec, nrow=p) %*% sqrtV
  }
  return(X)
}

mattgen <- function(n, U, V, df){
  p <- dim(U)[1]
  q <- dim(V)[1]
  cov = kronecker(V,U)
  X<-list()
  Xvec = rmvt(n, sigma = cov, df)
  for(i in 1:n){
    X[[i]] <- matrix(Xvec[i,], nrow=p)
  }
  return(X)
}

## Find the index of columns which are correlated to a-th column of X (penalty= lam)
matrixcolsel <- function(X,a,lam){
  lassofit <- glmnet(x = X[,-a], y = X[,a], alpha = 1, lambda = lam, standardize = F, intercept = FALSE)
  lassocoef <- coef(lassofit)
  nonzero <- which(lassocoef[-1] != 0)
  nonzero <- ifelse(nonzero >= a, nonzero+1, nonzero)
  return(nonzero)
}

matrixrowsel <- function(X,a,lam, standardize_glmnet){
  lassofit <- glmnet(x = t(X[-a,]), y = t(X[a,]), alpha = 1, lambda = lam, standardize = F, intercept = FALSE)
  lassocoef <- coef(lassofit)
  nonzero <- which(lassocoef[-1] != 0)
  nonzero <- ifelse(nonzero >= a, nonzero+1, nonzero)
  return(nonzero)
}

## Compute the graph structure of the column of X, from i.i.d data Xlist (list of n matrices) 
matrixcolNS <- function(Xlist,lam,
                        standardize = FALSE,
                        standardize_glmnet = FALSE){
  X<-do.call(rbind, Xlist)
  # X <- scale(X, center = standardize, scale = standardize)
  q<-ncol(X)
  a <- 1:q
  graph <- lapply(a, function(a) matrixcolsel(X, a, lam))
  cor_and <- diag(q)
  cor_or <- diag(q)
  for(i in 1:q){
    for(j in 1:q){
      if(j %in% graph[[i]] && i %in% graph[[j]]){
        cor_and[i,j] <- 1
        cor_and[j,i] <- 1
      }
      if (j %in% graph[[i]] || i %in% graph[[j]]){
        cor_or[i,j] <- 1
        cor_or[j,i] <- 1
      }
    }
  }
  return(list(and=cor_and, or=cor_or))
}

#matrixcolNS <- function(Xlist,lam,
#                        standardize = FALSE,
#                        standardize_glmnet = FALSE){
#  X<-do.call(rbind, Xlist)
#  # X <- scale(X, center = standardize, scale = standardize)
#  q<-ncol(X)
#  a <- 1:q
#  graph <- do.call(rbind, lapply(a, function(a) matrixcolsel(X, a, lam)))
##  and <- list()
#  or <- list()
#  for(.lam in seq_along(lam)){
#    tmp <- matrix(graph[,.lam], q, q)
#    and[[.lam]] <- tmp * t(tmp)
#    or[[.lam]] <- 1 * (tmp + t(tmp) > 0)
#  }
#  return(list(and = and, or = or))
#}

 matrixrowNS <- function(Xlist,lam, 
                         standardize = FALSE, 
                        standardize_glmnet = FALSE){
  X<-do.call(cbind, Xlist)
  X <- scale(X, center = standardize, scale = standardize)
   p<-nrow(X)
   a <- 1:p
   graph <- lapply(a, function(a) matrixrowsel(X, a, lam))
   cor_and <- diag(p)
   cor_or <- diag(p)
   for(i in 1:p){
     for(j in 1:p){
       if(j %in% graph[[i]] && i %in% graph[[j]]){
         cor_and[i,j] <- 1
         cor_and[j,i] <- 1
       }
       if (j %in% graph[[i]] || i %in% graph[[j]]){
         cor_or[i,j] <- 1
         cor_or[j,i] <- 1
       }
     }
   }
   return(list(and=cor_and, or=cor_or))
 }

## Graph estimation by Gemini(Zhou, 2014) method
GeminirowNS <- function (Xlist, rowpen, penalize.diagonal = FALSE) 
{
  n <- length(Xlist)
  p <- nrow(Xlist[[1]])
  q <- ncol(Xlist[[1]])
  Sigma.hat.U <- Reduce(`+`, lapply(Xlist, function(X) X %*% t(X)))
  Gamma.hat.U <- stats::cov2cor(Sigma.hat.U)
  glasso.U <- glasso::glasso(Gamma.hat.U, rowpen, penalize.diagonal = penalize.diagonal)
  #glasso.U <- glasso::glassopath(Gamma.hat.U, rowpen, penalize.diagonal = penalize.diagonal, trace = F)
  ## sd.row <- diag(sqrt(diag(Sigma.hat.U)/n))
  ## inv.sd.row <- diag(1/sqrt(diag(Sigma.hat.U)/n))
  ## U.hat.inv <- inv.sd.row %*% glasso.U$wi %*% inv.sd.row
  U.hat.inv <- glasso.U$wi
  return(ifelse(U.hat.inv != 0, 1, 0))
}

GeminirowNS_SP <- function (Xlist, rowpen, penalize.diagonal = FALSE) 
{
  n <- length(Xlist)
  p <- nrow(Xlist[[1]])
  q <- ncol(Xlist[[1]])
  Sigma.hat.U <- Reduce(`+`, lapply(Xlist, function(X) X %*% t(X)))
  Gamma.hat.U <- stats::cov2cor(Sigma.hat.U)
  #glasso.U <- glasso::glasso(Gamma.hat.U, rowpen, penalize.diagonal = penalize.diagonal)
  glasso.U <- glasso::glassopath(Gamma.hat.U, rowpen, penalize.diagonal = penalize.diagonal, trace = F)
  ## sd.row <- diag(sqrt(diag(Sigma.hat.U)/n))
  ## inv.sd.row <- diag(1/sqrt(diag(Sigma.hat.U)/n))
  ## U.hat.inv <- inv.sd.row %*% glasso.U$wi %*% inv.sd.row
  U.hat.inv <- glasso.U$wi
  return(ifelse(U.hat.inv != 0, 1, 0))
}

GeminicolNS <- function (Xlist, colpen, penalize.diagonal = FALSE) 
{
  n <- length(Xlist)
  p <- nrow(Xlist[[1]])
  q <- ncol(Xlist[[1]])
  Sigma.hat.V <- Reduce(`+`, lapply(Xlist, function(X) t(X) %*% X))
  Gamma.hat.V <- stats::cov2cor(Sigma.hat.V)
  glasso.V <- glasso::glasso(Gamma.hat.V, colpen, penalize.diagonal = penalize.diagonal)
  ## sd.col <- diag(sqrt(diag(Sigma.hat.V)/n))
  ## inv.sd.col <- diag(1/sqrt(diag(Sigma.hat.V)/n))
  ## V.hat.inv <- inv.sd.col %*% glasso.V$wi %*% inv.sd.col
  V.hat.inv <- glasso.V$wi
  return(ifelse(V.hat.inv != 0, 1, 0))
}

## Graph estimation by flip-flop likelihood based method (Leng, 2012)

LikeNS <- function(Xlist, rowpen, colpen){
  n <- length(Xlist)
  p <- nrow(Xlist[[1]])
  q <- ncol(Xlist[[1]])
  
  col.inv <- diag(q)
  col.inv.ref <- diag(q)
  row.inv <- 0
  row.inv.ref <- 0
  row.psi <- 0
  col.sigma <- 0
  count <- 0
  
  while(count < 100){
    row.psi <- Reduce(`+`, lapply(Xlist, function(X) X %*% col.inv %*% t(X)))/(n*q)
    row.inv.ref <- row.inv
    row.inv <- glasso(row.psi, rho=rowpen)$wi
    row.inv <- row.inv/row.inv[1,1]
    count <- count+1
    
    col.sigma <- Reduce(`+`, lapply(Xlist, function(X) t(X) %*% row.inv %*% X))/(n*p)
    col.inv.ref <- col.inv
    col.inv <- glasso(col.sigma, rho=colpen)$wi
    if(norm(col.inv-col.inv.ref, type="F") < 10^(-3) && norm(row.inv-row.inv.ref, type="F") < 10^(-3)){
      break
    }
  }
  return(list(row=ifelse(row.inv != 0, 1, 0), col=ifelse(col.inv != 0, 1, 0), iteration=count))
}


# Evaluate the performance of estimated graph(Est) against true graph(Ref)
evalNS <- function(Est, Ref){
  if(!identical(dim(Est), dim(Ref))){
    stop('The dimensions of input matrices are not identical')
  } else if(dim(Est)[1] != dim(Est)[2]){
    stop('Input matrices are not diagonal')
  }
  p <- dim(Est)[1]
  N <- p*(p-1)
  Est.graph <- ifelse(Est != 0, 1, 0)
  Ref.graph <- ifelse(Ref != 0, 1, 0)
  
  total.positive <- sum(Ref.graph[] == 1) - p
  total.negative <- sum(Ref.graph == 0)
  
  true.positive <- sum((Est.graph == 1) * (Ref.graph == 1)) - p
  true.negative <- sum((Est.graph == 0) * (Ref.graph == 0))
  false.positive <- sum((Est.graph == 1) * (Ref.graph == 0))
  false.negative <- sum((Est.graph == 0) * (Ref.graph == 1))
  false.positive.rate <- false.positive/total.negative
  false.negative.rate <- false.negative/total.positive
  return(list(true.positive=true.positive, true.negative=true.negative, false.positive=false.positive, false.negative=false.negative,
    false.positive.rate=false.positive.rate, false.negative.rate=false.negative.rate))
}

evalSigma <- function(rowEst, colEst, rowRef, colRef){
  if(!identical(dim(rowEst), dim(rowRef)) || !identical(dim(colEst), dim(colRef))){
    stop('The dimensions of input matrices are not identical')
  } else if(dim(rowEst)[1] != dim(rowEst)[2] || dim(colEst)[1] != dim(colEst)[2]){
    stop('Input matrices are not diagonal')
  }
  p <- dim(rowEst)[1]
  q <- dim(colEst)[1]
  
  A1 <- evalNS(rowEst, rowRef)$true.positive + p
  A2 <- evalNS(rowEst, rowRef)$false.negative
  A3 <- evalNS(rowEst, rowRef)$false.positive
  A4 <- evalNS(rowEst, rowRef)$true.negative
  
  B1 <- evalNS(colEst, colRef)$true.positive + q
  B2 <- evalNS(colEst, colRef)$false.negative
  B3 <- evalNS(colEst, colRef)$false.positive
  B4 <- evalNS(colEst, colRef)$true.negative
  
  true.positive <- A1*B1 - p*q
  false.negative <- A1*B2 + A2*B1 + A2*B2
  false.positive <- A1*B3 + A3*B1 + A3*B3
  true.negative <- A1*B4 + A2*B3 + A2*B4 + A3*B2 + A4*B1 + A4*B2 + A3*B4 + A4*B3 + A4*B4
  total.positive <- true.positive + false.negative
  total.negative <- false.positive + true.negative
  false.positive.rate <- false.positive/total.negative
  false.negative.rate <- false.negative/total.positive
  
  return(list(true.positive=true.positive, true.negative=true.negative, false.positive=false.positive, false.negative=false.negative,
              false.positive.rate=false.positive.rate, false.negative.rate=false.negative.rate))
}


## for parallel computing
test_naming <- function(row){
  name <- paste("n", row[1], "_","p",row[2],"_","q", row[3],"_", as.character(row[4]), sep="")
  name <- gsub(" ", "", name)
  return(name)
}

mysum <- function(a,b){
  a+b
}

myAUC <- function(fpr,tpr){
  sum((fpr[-length(fpr)] - fpr[-1]) * (tpr[-1] + tpr[-length(tpr)])) / 2
}

myAUC2 <- function(fpr,tpr){
  index <- which(fpr <= 0.15)
  index_over15 <- min(index)-1
  fpr2 = c(0.15, fpr[index])
  tpr2 = c(tpr[index_over15]-(0.15-fpr[min(index)])*(tpr[index_over15]-tpr[min(index)])/(fpr[index_over15]-fpr[min(index)]) , tpr[index])
  sum((fpr2[-length(fpr2)] - fpr2[-1]) * (tpr2[-1] + tpr2[-length(tpr2)])) / 0.3
}

## individual tuning based on CV
matrixcolsel_cv <- function(X,a,lamvec){
  lam_opt <- cv.glmnet(x= X[,-a], y= X[,a], lambda=global_para$lambda, standardize = FALSE)$lambda.min
  lassofit <- glmnet(x = X[,-a], y = X[,a], alpha = 1, lambda = lam_opt, standardize = FALSE)
  lassocoef <- coef(lassofit)
  nonzero <- which(lassocoef[-1] != 0)
  nonzero <- ifelse(nonzero >= a, nonzero+1, nonzero)
  return(nonzero)
}

# matrixrowsel_cv <- function(X,a,lamvec){
#   lam_opt <- cv.glmnet(x = t(X[-a,]), y = t(X[a,]), lambda=global_para$lambda, standardize = FALSE)$lambda.min
#   lassofit <- glmnet(x = t(X[-a,]), y = t(X[a,]), alpha = 1, lambda = lam_opt, standardize = FALSE)
#   lassocoef <- coef(lassofit)
#   nonzero <- which(lassocoef[-1] != 0)
#   nonzero <- ifelse(nonzero >= a, nonzero+1, nonzero)
#   return(nonzero)
# }

matrixcolNS_cv <- function(Xlist,lamvec, 
                           standardize = FALSE){
  X<-do.call(rbind, Xlist)
  X <- scale(X, center = standardize, scale = standardize)
  q<-ncol(X)
  a <- 1:q
  graph <- lapply(a, function(a) matrixcolsel_cv(X, a, lamvec))
  cor_and <- diag(q)
  cor_or <- diag(q)
  for(i in 1:q){
    for(j in 1:q){
      if(j %in% graph[[i]] && i %in% graph[[j]]){
        cor_and[i,j] <- 1
        cor_and[j,i] <- 1
      }
      if (j %in% graph[[i]] || i %in% graph[[j]]){
        cor_or[i,j] <- 1
        cor_or[j,i] <- 1
      }
    }
  }
  return(list(and=cor_and, or=cor_or))
}
# matrixrowNS_cv <- function(Xlist,lamvec){
#   X<-do.call(cbind, Xlist)
#   p<-nrow(X)
#   a <- 1:p
#   graph <- lapply(a, function(a) matrixrowsel_cv(X, a, lamvec))
#   cor_and <- diag(p)
#   cor_or <- diag(p)
#   for(i in 1:p){
#     for(j in 1:p){
#       if(j %in% graph[[i]] && i %in% graph[[j]]){
#         cor_and[i,j] <- 1
#         cor_and[j,i] <- 1
#       }
#       if (j %in% graph[[i]] || i %in% graph[[j]]){
#         cor_or[i,j] <- 1
#         cor_or[j,i] <- 1
#       }
#     }
#   }
#   return(list(and=cor_and, or=cor_or))
# }

## vectorized approach
vecNSsel <- function(Xlist,lam,
                     standardize = FALSE,
                     standardize_glmnet = FALSE){
  n <- length(Xlist)
  p <- nrow(Xlist[[1]])
  q <- ncol(Xlist[[1]])
  vecX_list<-lapply(Xlist, as.vector)
  vecX<-do.call(rbind, vecX_list)
  a <- 1:(p*q)
  graph <- lapply(a, function(a) matrixcolsel(vecX, a, lam))
# graph <- do.call(rbind,lapply(a, function(a) matrixcolsel(vecX, a, lam)))
#  and <- list()
#  or <- list()
#  for(.lam in seq_along(lam)){
#    tmp <- matrix(graph[,.lam], p*q, p*q)
#    and[[.lam]] <- tmp * t(tmp)
#    or[[.lam]] <- 1 * (tmp + t(tmp) > 0)
#  }
#  return(list(and = and, or = or))
  cor_and <- diag(p*q)
  cor_or <- diag(p*q)
  for(i in 1:(p*q)){
    for(j in 1:(p*q)){
      if(j %in% graph[[i]] && i %in% graph[[j]]){
        cor_and[i,j] <- 1
        cor_and[j,i] <- 1
      }
      if (j %in% graph[[i]] || i %in% graph[[j]]){
        cor_or[i,j] <- 1
        cor_or[j,i] <- 1
      }
    }
  }
  return(list(and=cor_and, or=cor_or))
}

vecglassosel <- function (Xlist, lam, penalize.diagonal = FALSE) 
{
  n <- length(Xlist)
  p <- nrow(Xlist[[1]])
  q <- ncol(Xlist[[1]])
  vecX_list<-lapply(Xlist, as.vector)
  vecX<-do.call(rbind, vecX_list)
  Sigma.hat <- cov(vecX)
  glasso.U <- glasso::glasso(Sigma.hat, lam, penalize.diagonal = penalize.diagonal, trace = F)
  #glasso.U <- glasso::glassopath(Sigma.hat, lam, penalize.diagonal = penalize.diagonal, trace = F)
  ## sd.row <- diag(sqrt(diag(Sigma.hat.U)/n))
  ## inv.sd.row <- diag(1/sqrt(diag(Sigma.hat.U)/n))
  ## U.hat.inv <- inv.sd.row %*% glasso.U$wi %*% inv.sd.row
  U.hat.inv <- glasso.U$wi
  return(ifelse(U.hat.inv != 0, 1, 0))
}

## Visualization
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}

gg_mat <- function(mat){
  dimnames(mat) <- NULL
  dat <- reshape2::melt(mat)
  ggplot(data = dat) +
    geom_tile(aes(x = Var2, y = Var1, fill = value),
              color = "white") +
    scale_fill_gradient2(low = "red", high = "blue", mid = "white",
                         limits = c(-max(abs(dat$value)), max(abs(dat$value)))) +
    labs(x = "", y = "") +
    theme_bw() +
    theme(legend.key.size = unit(1.5, "cm"), legend.key.height = unit(0.5,"cm"), legend.position = "top") +
    scale_y_reverse() +
    coord_fixed(ratio = 1)
}


